class Game {
    constructor() {
        this.playerLevel = 0
        this.computerSequence = []
        this.playerSequence = []
    }
    
    createSequence(){
        this.computerSequence = []
        const SequenceLength = this.playerLevel+1
        console.log("Taille liste", SequenceLength)
        for(let i = 0 ; i<SequenceLength ; i++){
            // console.log(this.computerSequence, this.SequenceLength)
            this.computerSequence.push(Math.floor(Math.random() * 4)) ;
        }
        console.log(this.computerSequence)   
    }


    addNewElementToTheUserSequence(colorColor){
        if(this.playerSequence.length<this.computerSequence.length){
            this.playerSequence.push(colorColor)
        } else {
            console.log('Next Round')
        }
    }
    
    isColorValid(){
        if(this.playerSequence[this.playerSequence.length - 1]== this.computerSequence[this.playerSequence.length - 1]){
            return true
        }
        return false
    }
    
}
