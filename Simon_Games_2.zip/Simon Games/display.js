class Display {
    constructor(){
        this.game = new Game()
        this.buttons = document.querySelectorAll('.colorButton')
        this.play = document.querySelector(".Play")
        this.ColorOff = ['rgba(255, 255, 0, 0.5)', 'rgba(255, 0, 0, 0.5)', 'rgba(0, 0, 255, 0.5)', 'rgba(0, 128, 0, 0.5)']
        this.ColorOn = ['rgba(255, 255, 0, 1.0)', 'rgba(255, 0, 0, 1.0)', 'rgba(0, 0, 255, 1.0)', 'rgba(0, 128, 0, 1.0)']

        this.isPlayerTurn = false
        this.attachEvents()
    }

    attachEvents(){
        this.play.addEventListener("click", ()=>{
            this.game.playerSequence = []
            this.game.playerLevel = 0
            this.buttonSound = new Audio("sound_button.mp3");
            this.looseSound = new Audio("loose_button.mp3");
            this.game.createSequence()
            this.readComputerSequence()
            $('#points').text('1')
            $('button').css('background', 'red').text('Rejouer')
            $('h2').css('display', 'none')
            $('#game').css('display', 'flex')
            this.looseSound.stop();
        })

        this.buttons.forEach((button,buttonIndex)=>{
            button.addEventListener('click', () => {
                if(this.isPlayerTurn == true){
                    this.game.addNewElementToTheUserSequence(buttonIndex)
                    console.log("Index ->",this.game.playerSequence)
                    if(this.game.isColorValid()){
                        console.log("La couleur est correcte")

                        this.buttonSound.play();

                        if(this.game.playerSequence.length===this.game.computerSequence.length ){
                            this.game.playerLevel+=1
                            
                            this.nextRound()
                        }
                    } else {
                        this.looseSound.play();
                        console.log("La couleur est incorrecte")
                        // this.nextRound()
                        $('h2').css('display', 'block')
                        $('#game').css('display', 'none')
                        $('#game:hover').css('animation', 'shake 0.5s')
                    }
                }
            })
        })
    }

    readComputerSequence(){
        this.isPlayerTurn = false
        let index = 0
        const id = setInterval(()=>{
            console.log(index, this.game.computerSequence[index])
            this.ChangeColor(this.game.computerSequence[index])
            
            if(index>=this.game.computerSequence.length-1){
                clearInterval(id)
                this.isPlayerTurn = true
            }
            index++
        },1000)
    }

    ChangeColor(index){
        this.buttons[index].style.backgroundColor = this.ColorOff[index]
        setTimeout(()=>{
            this.buttons[index].style.backgroundColor = this.ColorOn[index]
        }, 500)
    
    }
    nextRound(){
        this.isPlayerTurn = false
        this.game.playerSequence=[]
        this.game.createSequence()
        this.readComputerSequence()
        $('#points').text(this.game.playerLevel).css()
        console.log("current level : ", this.game.playerLevel)
    }

}

const display = new Display()